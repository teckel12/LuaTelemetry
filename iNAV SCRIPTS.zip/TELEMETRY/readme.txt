This directory is for lua telemetry scripts.
Those scripts can be selected using DISPLAY page.
